# VaultWave

A secure wallet provider web app built with Vite and React.